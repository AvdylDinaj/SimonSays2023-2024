import java.util.*;
import java.util.logging.*;
public class controller extends model
{
    view vw=new view();
    public controller()
    {
        new model();
    }
    public static void main(String args[]) {
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : 
            	javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
           Logger.getLogger(controller.class.getName()).log(Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
           Logger.getLogger(controller.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
           Logger.getLogger(controller.class.getName()).log(Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
           Logger.getLogger(controller.class.getName()).log(Level.SEVERE, null, ex);
        }
        simon=new ArrayList<>();
        user=new ArrayList<>();
        for(int i=0;i<level;i++)
        {
            simon.add(Colors[(int)(Math.random()*6)]);
        }
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new controller().setVisible(true);	
            }
        });
    }

}
