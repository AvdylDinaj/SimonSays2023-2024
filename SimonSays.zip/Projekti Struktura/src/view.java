import javax.swing.*;
import java.util.*;
import java.awt.*;
public class view extends JFrame{
	public static int level=0;
	public static int score=0;
    public static boolean isCorrect = true;

    public static ArrayList<String> user;  
    public static ArrayList<String> simon;
    public static String[] Colors={"Red","Green","Blue",
    		"Yellow", "Black", "Orange"};

    public JButton BlueButton;
    public Label CheckScore;
    public JButton DecreaseLvButton;
    public JButton GreenButton;
    public JButton RaiseLvButton;
    public JButton RedButton;
    public Label STARTlabel;
    public JButton YellowButton;
    public Button finishButton;
    public JScrollPane jScrollPane1;
    public JScrollPane jScrollPane2;
    public JButton OrangeButton;
    public JTextArea jTextArea1;
    public JTextArea jTextArea2;
    public JTextField jTextField1;
    public Label levelLable;
    public JButton BlackButton;
    public view(){
    	simon=new ArrayList<>();
        user=new ArrayList<>();
        jScrollPane1 = new JScrollPane();
        jTextArea1 = new JTextArea();
        jScrollPane2 = new JScrollPane();
        jTextArea2 = new JTextArea();
        jTextField1 = new JTextField();
        GreenButton = new JButton();
        BlueButton = new JButton();
        YellowButton = new JButton();
        RedButton = new JButton();
        RaiseLvButton = new JButton();
        DecreaseLvButton = new JButton();
        levelLable = new Label();
        OrangeButton = new JButton();
        STARTlabel = new Label();
        finishButton = new Button();
        CheckScore = new Label();
        BlackButton = new JButton();
        jTextArea1.setColumns(20);
        jTextArea1.setRows(5);
        jScrollPane1.setViewportView(jTextArea1);
        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        setBackground(new Color(255, 255, 255));
        setUndecorated(true);
    }
}