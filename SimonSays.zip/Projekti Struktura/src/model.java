import javax.swing.*;

public class model extends view{
    public model(){
    jTextArea2.setColumns(20);
        jTextArea2.setRows(5);
        jScrollPane2.setViewportView(jTextArea2);

        jTextField1.setBackground(new java.awt.Color(204, 0, 204));
        jTextField1.setText("         LEVEL");

        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(255, 255, 255)); 
        setUndecorated(true);

        GreenButton.setBackground(new java.awt.Color(0, 255, 0));
        GreenButton.setText("Green");
        GreenButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                GreenButtonActionPerformed(evt);
            }
        });
        
        BlueButton.setBackground(new java.awt.Color(0, 0, 255));
        BlueButton.setText("Blue");
        BlueButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BlueButtonActionPerformed(evt);
            }
        });

        YellowButton.setBackground(new java.awt.Color(255, 255, 0));
        YellowButton.setText("Yellow");
        YellowButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                YellowButtonActionPerformed(evt);
            }
        });

        RedButton.setBackground(new java.awt.Color(255, 0, 0));
        RedButton.setText("Red");
        RedButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                RedButtonActionPerformed(evt);
            }
        });
        BlackButton.setBackground(new java.awt.Color(0,0,0));
        BlackButton.setForeground(new java.awt.Color(255,255,255));
        BlackButton.setText("Black");
        BlackButton.addActionListener(new java.awt.event.ActionListener() {
        public void actionPerformed(java.awt.event.ActionEvent evt) {
        	BlackButtonActionPerformed(evt);
           }
        });
        OrangeButton.setBackground(new java.awt.Color(255,102,0));
        OrangeButton.setText("Orange");
        OrangeButton.addActionListener(new java.awt.event.ActionListener() {
        	public void actionPerformed(java.awt.event.ActionEvent evt) {
        		OrangeButtonActionPerformed(evt);
        	}
        });

        RaiseLvButton.setBackground(new java.awt.Color(255, 0, 204));
        RaiseLvButton.setText("+");
        RaiseLvButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                RaiseLvButtonActionPerformed(evt);
            }
        });
        
        

        DecreaseLvButton.setBackground(new java.awt.Color(255, 153, 153));
        DecreaseLvButton.setText("-");
        DecreaseLvButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DecreaseLvButtonActionPerformed(evt);
            }
        });

        levelLable.setText("      LEVEL");
        levelLable.setBackground(new java.awt.Color(102,102,255));
        levelLable.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                levelLableMouseClicked(evt);
            }
        });

        STARTlabel.setBackground(new java.awt.Color(255, 51, 153));
        STARTlabel.setForeground(new java.awt.Color(255, 255, 255));
        STARTlabel.setText("    START!!");
        STARTlabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                STARTlabelMouseClicked(evt);
            }
        });

        finishButton.setBackground(new java.awt.Color(153, 0, 153));
        finishButton.setForeground(new java.awt.Color(255, 255, 255));
        finishButton.setLabel("FINISH!");
        finishButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                finishButtonActionPerformed(evt);
            }
        });

        CheckScore.setText("Check Score");
        CheckScore.setBackground(new java.awt.Color(0,204,204));
        CheckScore.setForeground(new java.awt.Color(0,0,0));
        CheckScore.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                CheckScoreMouseClicked(evt);
            }
        });
        
        GroupLayout layout = new GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addContainerGap()
                    .addComponent(STARTlabel)
                    .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(CheckScore, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
                    .addGap(35, 35, 35)
                    .addComponent(levelLable)
                    .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                    .addComponent(DecreaseLvButton, GroupLayout.PREFERRED_SIZE, 40, GroupLayout.PREFERRED_SIZE)
                    .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                    .addComponent(RaiseLvButton, GroupLayout.PREFERRED_SIZE, 40, GroupLayout.PREFERRED_SIZE)
                    .addGap(35, 35, 35)
                    .addComponent(finishButton)
                    .addContainerGap())
                .addGroup(layout.createSequentialGroup()
                    .addGap(80, 80, 80)
                    .addComponent(YellowButton, GroupLayout.PREFERRED_SIZE, 140, GroupLayout.PREFERRED_SIZE)
                    .addGap(40, 40, 40)
                    .addComponent(BlueButton, GroupLayout.PREFERRED_SIZE, 140, GroupLayout.PREFERRED_SIZE)
                    .addGap(80, 80, 80))
                .addGroup(layout.createSequentialGroup()
                    .addGap(80, 80, 80)
                    .addComponent(GreenButton, GroupLayout.PREFERRED_SIZE, 140, GroupLayout.PREFERRED_SIZE)
                    .addGap(40, 40, 40)
                    .addComponent(RedButton, GroupLayout.PREFERRED_SIZE, 140, GroupLayout.PREFERRED_SIZE)
                    .addGap(80, 80, 80))
                .addGroup(layout.createSequentialGroup()
                    .addGap(80, 80, 80)
                    .addComponent(BlackButton, GroupLayout.PREFERRED_SIZE, 140, GroupLayout.PREFERRED_SIZE)
                    .addGap(40, 40, 40)
                    .addComponent(OrangeButton, GroupLayout.PREFERRED_SIZE, 140, GroupLayout.PREFERRED_SIZE)
                    .addGap(80, 80, 80))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addContainerGap()
                    .addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                        .addComponent(STARTlabel)
                        .addComponent(CheckScore, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
                        .addComponent(levelLable)
                        .addComponent(DecreaseLvButton)
                        .addComponent(RaiseLvButton)
                        .addComponent(finishButton))
                    .addGap(18, 18, 18)
                    .addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                        .addComponent(YellowButton, GroupLayout.PREFERRED_SIZE, 120, GroupLayout.PREFERRED_SIZE)
                        .addComponent(BlueButton, GroupLayout.PREFERRED_SIZE, 120, GroupLayout.PREFERRED_SIZE))
                    .addGap(40, 40, 40)
                    .addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                        .addComponent(GreenButton, GroupLayout.PREFERRED_SIZE, 120, GroupLayout.PREFERRED_SIZE)
                        .addComponent(RedButton, GroupLayout.PREFERRED_SIZE, 120, GroupLayout.PREFERRED_SIZE))
                    .addGap(40, 40, 40)
                    .addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                        .addComponent(BlackButton, GroupLayout.PREFERRED_SIZE, 120, GroupLayout.PREFERRED_SIZE)
                        .addComponent(OrangeButton, GroupLayout.PREFERRED_SIZE, 120, GroupLayout.PREFERRED_SIZE))
                    .addContainerGap(30, Short.MAX_VALUE))
        );
         
        pack();
    }
    
        private void YellowButtonActionPerformed(java.awt.event.ActionEvent evt) {                                             
            user.add("Yellow");
        }                                            

        private void BlueButtonActionPerformed(java.awt.event.ActionEvent evt) {                                           
            user.add("Blue");
        }                                          

        private void GreenButtonActionPerformed(java.awt.event.ActionEvent evt) {                                            
            user.add("Green");
        }                                           

        private void RedButtonActionPerformed(java.awt.event.ActionEvent evt) {                                          
            user.add("Red");
        }
        private void BlackButtonActionPerformed(java.awt.event.ActionEvent evt) {
        	user.add("Black");
        }
        private void OrangeButtonActionPerformed(java.awt.event.ActionEvent evt) {
        	user.add("Orange");
        }
        

        private void RaiseLvButtonActionPerformed(java.awt.event.ActionEvent evt) {                                              
            level =level+1;
            simon.clear();
            for(int i=0;i<level;i++)
            {
                simon.add(Colors[(int)(Math.random()*6)]);
            }
        }                                             

        private void DecreaseLvButtonActionPerformed(java.awt.event.ActionEvent evt) { 
        	if (level ==0) {
        		JOptionPane.showMessageDialog(null, "Looks like you can't go at negative "
        				+ "levels. Why don't you try a higher level instead.");
        	}
        	else {
        		level= level-1;
            simon.clear();
            for(int i=0;i<level;i++)
        {
            simon.add(Colors[(int)(Math.random()*6)]);
        }
      }     
    }                                                

    private void levelLableMouseClicked(java.awt.event.MouseEvent evt) {                                        
        JOptionPane.showMessageDialog(null,"Your Current Level is :"+level);
    }                                       

    private void STARTlabelMouseClicked(java.awt.event.MouseEvent evt) {                                        
        String s="";
        for(int i=0;i<simon.size();i++) {
            s=s+simon.get(i)+" "; }
        JOptionPane.showMessageDialog(null,"Simon says: "+s);
    }                                       

    private void finishButtonActionPerformed(java.awt.event.ActionEvent evt) {                                             
        String s1="";
        for(int i=0;i<user.size();i++)
        {
            s1=s1+user.get(i)+" ";
        }
        JOptionPane.showMessageDialog(null,"You said: "+s1);
        for(int i=0;i<simon.size();i++) {
            if(user.get(i).equals(simon.get(i)))
                isCorrect=true;   
            else {
               isCorrect =false;
                break;
                }
            }

        if( isCorrect ) {
            level++;
            JOptionPane.showMessageDialog(null,"You got it!!(Your level now is: "+level+")");
            score++;
        }
        else  {
        	
        	level--;
            JOptionPane.showMessageDialog(null,"You are wrong‼(Your level now is: "+level+")");
            int reply = JOptionPane.showConfirmDialog(null, "Do you want to continue?", "Continue or no?",
            		JOptionPane.YES_NO_OPTION);
            if (reply == JOptionPane.YES_OPTION) 
            JOptionPane.showMessageDialog(null, "Hope you get it now!");
            else 
            {
            JOptionPane.showMessageDialog(null,"Goodbyee!");
            System.exit(0);
            }
        }
        user.clear();
        simon.clear();
        for(int i=0;i<level;i++)
        {
            simon.add(Colors[(int)(Math.random()*6)]);
        }
    }                                            

    private void CheckScoreMouseClicked(java.awt.event.MouseEvent evt) {                                        
        JOptionPane.showMessageDialog(null, "Your score so far is: "+score);
    }
}
